package com.example.numbershapes;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void onBtnCheckClick(View view) {

        EditText editText = (EditText) findViewById(R.id.editTextNumber);

        if ( editText.getText().toString().isEmpty() ) {
            Toast.makeText(this, "Please insert a number !", Toast.LENGTH_SHORT).show();
        } else {
            Number myNumber = new Number();

            myNumber.number = Integer.parseInt(editText.getText().toString());

            if (myNumber.isSquare() && myNumber.isTriangular()) {
                Toast.makeText(this, "This is a square and a triangular number !", Toast.LENGTH_SHORT).show();
            } else {
                if (myNumber.isTriangular()) {
                    Toast.makeText(this, "This is a triangular number !", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "This is a square number !", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}