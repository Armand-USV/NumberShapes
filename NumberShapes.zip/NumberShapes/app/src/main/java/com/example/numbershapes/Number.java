package com.example.numbershapes;

public class Number {

    int number ;

    public boolean isSquare() {

        double squareRoot = Math.sqrt( number ) ;

        return squareRoot == (int) squareRoot ;
    }

    public boolean isTriangular() {

        int x = 1 , triangularNumber = 1 ;

        while ( triangularNumber < number ) {
            triangularNumber += ++x ;
        }

        return triangularNumber == number;
    }
}
